saga-python
===========

A light-weight access layer for distributed computing infrastructure 

  www:  http://radical-cybertools.github.io/saga-python/
  wiki: https://github.com/radical-cybertools/saga-python/wiki


Unit Tests
----------

The unit tests for saga-python can be found in the tests/ subdirectory.
Instructions how to tun the tests are in tests/README.md.
 
SAGA-Python requires Python version 2.x, specifically version 2.5 or newer.


